{
	"title": "tinymce",
	"tests": [
		{"title": "Editor", "url": "Editor.html"},
		{"title": "EditorCommands", "url": "EditorCommands.html"},
		{"title": "EnterKey", "url": "EnterKey.html"},
		{"title": "ForceBlocks", "url": "ForceBlocks.html"},
		{"title": "Formatter (Apply)", "url": "Formatter_apply.html"},
		{"title": "Formatter (Remove)", "url": "Formatter_remove.html"},
		{"title": "Formatter (Check)", "url": "Formatter_check.html"},
		{"title": "Formatter (jsrobot)", "url": "Formatter_robot.html", "jsrobot":true},
		{"title": "UndoManager", "url": "UndoManager.html"},
		{"title": "Undo", "url": "UndoManager_robot.html", "jsrobot": true}
	]
}
